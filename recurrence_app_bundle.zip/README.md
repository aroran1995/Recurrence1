# Recurrent Air Leak Risk Calculator

This Streamlit app estimates the probability of recurrent air leak based on:
- Volume drained (mL)
- Time to resolution (minutes)

## 🚀 Run locally:

```bash
pip install -r requirements.txt
streamlit run recurrence_app.py
```

## 📁 Files:
- `recurrence_app.py`: the Streamlit app
- `Updated File Feb 9 (1).xlsx`: dataset
- `requirements.txt`: dependencies
